/* This is an automatically generated file. Do not edit. */

/* UniKS-UCS2-H */

static pdf_cmap cmap_UniKS_UCS2_H = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "UniKS-UCS2-H",
	/* usecmap */ "UniKS-X", NULL,
	/* wmode */ 0,
	/* codespaces */ 2, {
		{ 2, 0x0000, 0xd7ff },
		{ 2, 0xe000, 0xffff },
	},
	0, 0, NULL, /* ranges */
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
